package com.example.lamiaa.taskbook;

import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.Charset;

public class MainActivity extends AppCompatActivity {

    public static final String LOG_TAG = MainActivity.class.getSimpleName();
    private static final String USGS_REQUEST_URL =
            "https://www.googleapis.com/books/v1/volumes?q=android";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TsunamiAsyncTask task = new TsunamiAsyncTask();
        task.execute();
    }

    private void updateUi(Event listbook) {
        TextView titleTextView = (TextView) findViewById(R.id.title);
        titleTextView.setText(listbook.title);

        TextView tsunamiTextView = (TextView) findViewById(R.id.authors);
        tsunamiTextView.setText((CharSequence) autherNames(listbook.authors));

        TextView dateTextView = (TextView) findViewById(R.id.publisher);
        dateTextView.setText(listbook.publisher);

        TextView descriptionTextView = (TextView) findViewById(R.id.description);
        dateTextView.setText(listbook.description);


    }

    public  JSONArray autherNames(JSONArray authors){
        return authors;
    }

    private class TsunamiAsyncTask extends AsyncTask<URL, Void, Event> {

        @Override
        protected Event doInBackground(URL... urls) {
            URL url = createUrl(USGS_REQUEST_URL);
            String jsonResponse = "";
            try {
                jsonResponse = makeHttpRequest(url);
            } catch (IOException e) {
                // TODO Handle the IOException
            }

            Event listBook = extractFeatureFromJson(jsonResponse);
            return listBook;
        }

        @Override
        protected void onPostExecute(Event books) {
            if (books == null) {
                return;
            }

            updateUi(books);
        }

        private URL createUrl(String stringUrl) {
            URL url = null;
            try {
                url = new URL(stringUrl);
            } catch (MalformedURLException exception) {
                Log.e(LOG_TAG, "Error with creating URL", exception);
                return null;
            }
            return url;
        }


        private String makeHttpRequest(URL url) throws IOException {
            String jsonResponse = "";
            HttpURLConnection urlConnection = null;
            InputStream inputStream = null;
            try {
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("GET");
                urlConnection.setReadTimeout(10000);
                urlConnection.setConnectTimeout(15000);
                urlConnection.connect();
                inputStream = urlConnection.getInputStream();
                jsonResponse = readFromStream(inputStream);
            }
            catch (IOException e) {
                // TODO: Handle the exception
            } finally {
                if (urlConnection != null) {
                    urlConnection.disconnect();
                }
                if (inputStream != null) {
                    inputStream.close();
                }
            }
            return jsonResponse;
        }

        private String readFromStream(InputStream inputStream) throws IOException {
            StringBuilder output = new StringBuilder();
            if (inputStream != null) {
                InputStreamReader inputStreamReader = new InputStreamReader(inputStream, Charset.forName("UTF-8"));
                BufferedReader reader = new BufferedReader(inputStreamReader);
                String line = reader.readLine();
                while (line != null) {
                    output.append(line);
                    line = reader.readLine();
                }
            }
            return output.toString();
        }

        private Event extractFeatureFromJson(String bookJSON) {
            try {
                JSONObject baseJsonResponse = new JSONObject(bookJSON);
                JSONArray itemsArray = baseJsonResponse.getJSONArray("items");
                JSONArray autherArray = baseJsonResponse.getJSONArray("authors");
                if(itemsArray.length()>0)
                {
                     JSONObject firstitems = itemsArray.getJSONObject(0);
               //     JSONObject authername=autherArray.getJSONObject(0);
                    JSONObject volumeInfo = firstitems.getJSONObject("volumeInfo");
                    String title = volumeInfo.getString("title");
                    String publisher=volumeInfo.getString("publisher");
                    String description=volumeInfo.getString("description");

                    return new Event(title,autherArray, publisher, description);
                }
            } catch (JSONException e) {
                Log.e(LOG_TAG, "Problem list of tBook JSON results", e);
            }
            return null;
        }
    }
}
